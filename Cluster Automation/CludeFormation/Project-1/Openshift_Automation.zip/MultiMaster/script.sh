#! /bin/bash
yum -y install git
yum -y install epel-release
yum -y install python-pip
pip install ansible==2.6.5
git clone https://github.com/openshift/openshift-ansible
cd openshift-ansible
git checkout release-3.11
sudo chmod 700 /home/centos/DockerAutomation.pem

sudo python -m pip install --upgrade pip
sudo pip install -U setuptools
sudo export ANSIBLE_HOST_KEY_CHECKING=False
sudo ansible-playbook /home/centos/prepare.yaml -i /home/centos/Inventory --key-file /home/centos/DockerAutomation.pem
sudo ansible-playbook /home/centos/openshift-ansible/playbooks/prerequisites.yml -i /home/centos/Inventory --key-file /home/centos/DockerAutomation.pem
sudo ansible-playbook /home/centos/openshift-ansible/playbooks/deploy_cluster.yml -i /home/centos/Inventory --key-file /home/centos/DockerAutomation.pem
sudo ansible-playbook /home/centos/openshift-ansible/playbooks/openshift-node/bootstrap.yml -i /home/centos/Inventory --key-file /home/centos/DockerAutomation.pem
sudo ansible-playbook /home/centos/openshift-ansible/playbooks/deploy_cluster.yml -i /home/centos/Inventory --key-file /home/centos/DockerAutomation.pem