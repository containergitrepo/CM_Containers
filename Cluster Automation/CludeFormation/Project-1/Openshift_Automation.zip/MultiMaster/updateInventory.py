import sys
import configparser

if __name__=='__main__':
    print(sys.argv[1])  
    print(sys.argv[2])   
    cfg=configparser.ConfigParser(allow_no_value=True)
    path='C:/Users/prkarekar/Desktop/Project/Openshift/MultiNode/Inventory'
    c=cfg.read(path)
    appstr="app."+str(sys.argv[1])
    print(appstr)
    cfg.set("OSEv3:vars","openshift_master_default_subdomain",appstr)
    cfg.set("OSEv3:vars","openshift_master_cluster_public_hostname",str(sys.argv[1]))
    cfg.set("OSEv3:vars","openshift_master_cluster_hostname",str(sys.argv[1]))
    cfg["masters"]={}
    cfg.set("masters",str(sys.argv[2]))
    cfg["etcd"]={}
    cfg.set("etcd",str(sys.argv[2]))
    cfg["nodes"]={}
    str1=str(sys.argv[2])+" "+"openshift_node_group_name = 'node-config-master-infra' openshift_schedulable=true"
    str2=str(sys.argv[3])+" "+"openshift_node_group_name = 'node-config-compute'"
    str3=str(sys.argv[4])+" "+"openshift_node_group_name = 'node-config-compute'"
    cfg.set("nodes",str1)
    cfg.set("nodes",str2)
    cfg.set("nodes",str3)


    with open("Inventory", "w+") as configfile:
        cfg.write(configfile)