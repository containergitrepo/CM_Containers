#!/bin/bash -e
aws cloudformation create-stack --stack-name OpenshiftMaster --template-body file://Master.yaml --parameters file://MasterParam.json
aws cloudformation wait stack-create-complete --stack-name OpenshiftMaster

aws cloudformation create-stack --stack-name OpenshiftWorker --template-body file://Worker.yaml --parameters file://WorkerParam.json
aws cloudformation wait stack-create-complete --stack-name OpenshiftWorker


msnode=$(aws ec2 describe-tags --filters "Name=tag:Name,Values=openshift-MasterNode" --query "Tags[1].ResourceId" --output text)
aws ec2 delete-tags --resources $msnode --tags Key=Name,Value=openshift-MasterNode
aws ec2 create-tags --resources $msnode  --tags Key=Name,Value=openshift-MasterNode-2

Masterpubip1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-MasterNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Masterpubip1

Masterprip1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-MasterNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Masterprip1


Masterpubip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-MasterNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Masterpubip2

Masterprip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-MasterNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Masterprip2

ManagerNodeSGid1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-MasterNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].SecurityGroups[*].GroupId" --output text)
echo $ManagerNodeSGid1

sgip="$Masterpubip1/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Masterprip1/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Masterpubip2/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Masterprip2/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

DNS=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-MasterNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicDnsName" --output text)
echo $DNS

if [ $1 == "1" ]
then
echo "its 1"
Workerpubip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Workerpubip

Workerprip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Workerprip

sgip="$Workerprip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Workerpubip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1
echo "=============== sg update worker ========================"


workerNodeSGid1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].SecurityGroups[*].GroupId" --output text)
echo $workerNodeSGid1

sgip="$Masterpubip1/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $workerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Masterprip1/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $workerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1



echo "======================openshift setup started============================="

ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(echo '$Workerprip' | sudo tee -a /etc/hosts)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(echo '$Workerprip2' | sudo tee -a /etc/hosts)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo chmod 777 script.sh)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo rm -rf /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo cp /home/centos/ansible-hosts_template1 /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/public_ipm/$DNS/g' /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/private_ipm1/$Masterprip1/g' /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/private_ipm2/$Masterprip2/g' /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/private_ipw1/$Workerprip/g' /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo ./script.sh)'
echo "======================openshift setup completed============================="
fi

if [ $1 == "2" ]
then
echo "its 2"
node=$(aws ec2 describe-tags --filters "Name=tag:Name,Values=openshift-WorkerNode" --query "Tags[1].ResourceId" --output text)
aws ec2 delete-tags --resources $node --tags Key=Name,Value=openshift-WorkerNode
aws ec2 create-tags --resources $node  --tags Key=Name,Value=openshift-WorkerNode-2

echo "===============sg update 1========================"
Workerpubip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Workerpubip

Workerprip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Workerprip

sgip="$Workerprip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Workerpubip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1


echo "===============sg update 2========================"
Workerpubip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Workerpubip2

Workerprip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Workerprip2

sgip="$Workerprip2/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Workerpubip2/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1
echo "=============== sg update worker ========================"


workerNodeSGid1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].SecurityGroups[*].GroupId" --output text)
echo $workerNodeSGid1

sgip="$Masterpubip1/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $workerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Masterprip1/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $workerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1



echo "======================openshift setup started============================="


ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(echo '$Workerprip' | sudo tee -a /etc/hosts)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(echo '$Workerprip2' | sudo tee -a /etc/hosts)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo chmod 777 script.sh)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo rm -rf /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo cp /home/centos/ansible-hosts_template2 /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/public_ipm/$DNS/g' /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/private_ipm1/$Masterprip1/g' /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/private_ipm2/$Masterprip2/g' /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/private_ipw1/$Workerprip/g' /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/private_ipw2/$Workerprip2/g' /home/centos/Inventory)'
ssh -o "ServerAliveInterval=300" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo ./script.sh)'
echo "======================openshift setup completed============================="
fi

if [ $1 == "3" ]
then
echo "its 3"
id2=$(aws ec2 describe-tags --filters "Name=tag:Name,Values=openshift-WorkerNode" --query "Tags[1].ResourceId" --output text)
#echo $id2


id3=$(aws ec2 describe-tags --filters "Name=tag:Name,Values=openshift-WorkerNode" --query "Tags[2].ResourceId" --output text)
#echo $id3

aws ec2 delete-tags --resources $id2 --tags Key=Name,Value=openshift-WorkerNode
aws ec2 delete-tags --resources $id3 --tags Key=Name,Value=openshift-WorkerNode

aws ec2 create-tags --resources $id2  --tags Key=Name,Value=openshift-WorkerNode-2
aws ec2 create-tags --resources $id3  --tags Key=Name,Value=openshift-WorkerNode-3

echo "===============sg update 1========================"
Workerpubip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Workerpubip

Workerprip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Workerprip

sgip="$Workerprip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Workerpubip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1


echo "===============sg update 2========================"
Workerpubip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Workerpubip2

Workerprip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Workerprip2

sgip="$Workerprip2/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Workerpubip2/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

echo "===============sg update 3========================"
Workerpubip3=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode-3" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Workerpubip3

Workerprip3=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode-3" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Workerprip3

sgip="$Workerprip3/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Workerpubip3/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1
echo "=============== sg update worker ========================"


workerNodeSGid1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=openshift-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].SecurityGroups[*].GroupId" --output text)
echo $workerNodeSGid1

sgip="$Masterpubip1/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $workerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Masterprip1/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $workerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

echo "======================openshift setup started============================="


ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(echo '$Workerprip' | sudo tee -a /etc/hosts)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(echo '$Workerprip2' | sudo tee -a /etc/hosts)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo chmod 777 script.sh)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo rm -rf /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo cp /home/centos/ansible-hosts_template3 /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/public_ipm/$DNS/g' /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/private_ipm1/$Masterprip1/g' /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/private_ipm2/$Masterprip2/g' /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/private_ipw1/$Workerprip/g' /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/private_ipw2/$Workerprip2/g' /home/centos/Inventory)'
ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo sed -i 's/private_ipw3/$Workerprip3/g' /home/centos/Inventory)'
ssh -o "ServerAliveInterval=300" -i DockerAutomation.pem centos@$Masterpubip1 '(sudo ./script.sh)'
echo "======================openshift setup completed============================="

fi


