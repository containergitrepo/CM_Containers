#!/bin/bash -e
aws cloudformation create-stack --stack-name KubernetesMaster --template-body file://KuberneteMaster.yaml --parameters file://KubernetesMasterParam.json
aws cloudformation wait stack-create-complete --stack-name KubernetesMaster

msnode=$(aws ec2 describe-tags --filters "Name=tag:Name,Values=Kubernetes-MasterNode" --query "Tags[1].ResourceId" --output text)
aws ec2 delete-tags --resources $msnode --tags Key=Name,Value=Kubernetes-MasterNode
aws ec2 create-tags --resources $msnode  --tags Key=Name,Value=Kubernetes-MasterNode-2


Masterpubip1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-MasterNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Masterpubip1

Masterprip1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-MasterNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Masterprip1


Masterpubip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-MasterNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Masterpubip2

Masterprip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-MasterNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Masterprip2

python updateJson.py $Masterprip1

aws cloudformation create-stack --stack-name NetworkELB1 --template-body file://NetworkELB.yaml --parameters file://ELBParams.json
aws cloudformation wait stack-create-complete --stack-name NetworkELB1

DNS=$(aws elbv2 describe-load-balancers --names kubenetesclusterelb --output text --query "LoadBalancers[*].DNSName")
DNSUrl="$DNS:6443"

sleep 1m
ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Masterpubip1 '(sudo sed -i 's/LOAD_BALANCER_DNS/$DNSUrl/g' /home/ubuntu/kubeadm-config.yaml)'

initMaster=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Masterpubip1 '(sudo kubeadm init --config=kubeadm-config.yaml --upload-certs)')
echo $initMaster
#sleep 1m

mkdir=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Masterpubip1 '(mkdir -p $HOME/.kube)')
echo $mkdir

cp=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Masterpubip1 '(sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config)')
echo $cp

chown=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Masterpubip1 '(sudo chown $(id -u):$(id -g) $HOME/.kube/config)')
echo $chown

token=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Masterpubip1 '(kubeadm token create --print-join-command)')
echo $token

cert=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Masterpubip1 '(sudo kubeadm init phase upload-certs --upload-certs)')
echo $cert


val1=$(echo $cert | tr '"' "'" )

#val1="$cert"

echo $val1

IFS=":" read name value <<< $val1

echo $value

joinmaster="$token --control-plane --certificate-key $value"

echo $joinmaster

addmaster=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Masterpubip2 '( sudo '$joinmaster')')
echo $addmaster

setup=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Masterpubip1 '/home/ubuntu/test.sh')

echo "-------------------------Add worker nodes-------------------"

aws cloudformation create-stack --stack-name KubernetesWorker --template-body file://KubertenesWorker.yaml --parameters file://KubernetesWorkerParam.json
aws cloudformation wait stack-create-complete --stack-name KubernetesWorker

sleep 1m

join=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Masterpubip1 '(kubeadm token create --print-join-command)')
echo $join

ManagerNodeSGid1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-MasterNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].SecurityGroups[*].GroupId" --output text)

if [ $1 == "1" ]
then
echo "its 1"
Workerpubip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Workerpubip

Workerprip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Workerprip

sgip="$Workerprip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Workerpubip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

addnode=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Workerpubip '( sudo '$join')' )
echo $addnode

fi

if [ $1 == "2" ]
then
echo "its 2"
id2=$(aws ec2 describe-tags --filters "Name=tag:Name,Values=Kubernetes-WorkerNode" --query "Tags[1].ResourceId" --output text)
#echo $id2
aws ec2 delete-tags --resources $id2 --tags Key=Name,Value=Kubernetes-WorkerNode
aws ec2 create-tags --resources $id2  --tags Key=Name,Value=Kubernetes-WorkerNode-2
echo "===============sg update 1========================"
Workerpubip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Workerpubip

Workerprip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Workerprip

sgip="$Workerprip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Workerpubip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

addnode=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Workerpubip '( sudo '$join')' )
echo $addnode
echo "===============sg update 2========================"
Workerpubip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Workerpubip

Workerprip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Workerprip

sgip="$Workerprip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Workerpubip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

addnode=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Workerpubip '( sudo '$join')' )
echo $addnod
fi

if [ $1 == "3" ]
then
echo "its 3"
id2=$(aws ec2 describe-tags --filters "Name=tag:Name,Values=Kubernetes-WorkerNode" --query "Tags[1].ResourceId" --output text)
#echo $id2


id3=$(aws ec2 describe-tags --filters "Name=tag:Name,Values=Kubernetes-WorkerNode" --query "Tags[2].ResourceId" --output text)
#echo $id3

aws ec2 delete-tags --resources $id2 --tags Key=Name,Value=Kubernetes-WorkerNode
aws ec2 delete-tags --resources $id3 --tags Key=Name,Value=Kubernetes-WorkerNode

aws ec2 create-tags --resources $id2  --tags Key=Name,Value=Kubernetes-WorkerNode-2
aws ec2 create-tags --resources $id3  --tags Key=Name,Value=Kubernetes-WorkerNode-3

echo "===============sg update 1========================"
Workerpubip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Workerpubip

Workerprip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Workerprip

sgip="$Workerprip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Workerpubip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1
addnode=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Workerpubip '( sudo '$join')' )
echo $addnod
echo "===============sg update 2========================"
Workerpubip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Workerpubip

Workerprip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Workerprip

sgip="$Workerprip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Workerpubip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

addnode=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Workerpubip '( sudo '$join')' )
echo $addnod

echo "===============sg update 3========================"
Workerpubip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-WorkerNode-3" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $Workerpubip

Workerprip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-WorkerNode-3" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $Workerprip

sgip="$Workerprip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

sgip="$Workerpubip/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

addnode=$(ssh -o "StrictHostKeyChecking no" -i containerization-Automation-Pranali.pem ubuntu@$Workerpubip '( sudo '$join')' )
echo $addnod
fi

