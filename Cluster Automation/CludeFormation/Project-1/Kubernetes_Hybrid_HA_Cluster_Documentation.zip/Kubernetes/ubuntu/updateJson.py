import json
import sys

print(sys.argv[1])
with open("ELBParams.json", "r") as jsonFile:
    data = json.load(jsonFile)
    for d in data :
        if d['ParameterKey']=="MasterIp":
            print (d['ParameterValue'])
            d['ParameterValue']=sys.argv[1]
            with open("ELBParams.json", "w") as jsonFile:
                json.dump(data, jsonFile)
        
