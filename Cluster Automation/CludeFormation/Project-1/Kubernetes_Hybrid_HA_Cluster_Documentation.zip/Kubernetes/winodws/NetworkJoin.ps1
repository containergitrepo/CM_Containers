$Masterpubip = $args[0]
echo $Masterpubip
$workerip = $args[1]
echo $workerip
echo Y | pscp -i C:\k\Key\containerization-Automation-Pranali.ppk ubuntu@"$Masterpubip":/home/ubuntu/winodwsconfigcopy/config C:\k 
$env:Path += ";C:\k"
[Environment]::SetEnvironmentVariable("Path", $env:Path + ";C:\k", [EnvironmentVariableTarget]::Machine)
$env:KUBECONFIG="C:\k\config"
[Environment]::SetEnvironmentVariable("KUBECONFIG", "C:\k\config", [EnvironmentVariableTarget]::User)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
wget https://raw.githubusercontent.com/Microsoft/SDN/master/Kubernetes/flannel/start.ps1 -o c:\k\start.ps1
cd c:\k
.\start.ps1 -ManagementIP $workerip -NetworkMode overlay  -ClusterCIDR 10.244.0.0/16 -ServiceCIDR 10.96.0.0/12 -KubeDnsServiceIP 10.96.0.10 -LogDir C:\k -InterfaceName Ethernet



