
$Username="Administrator"
$Password='6uff(54P)MYgPDYGax-uzSfxI5E$MP-@'
$pass = ConvertTo-SecureString -AsPlainText $Password -Force
$Cred = New-Object System.Management.Automation.PSCredential -ArgumentList $Username,$pass

$ManagerNodeSGid1=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-MasterNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].SecurityGroups[*].GroupId" --profile mfa --output text
$Masterpubip=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubernetes-MasterNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text --profile mfa 
echo $Masterpubip


$input = $args[0]
echo $input
 
if($input -eq 1)
{
    write-host("Value of X is 1")
    #Start-Sleep -s 60

    $pubip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
    echo $pubip1
    $prip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
    echo $prip1

    $sgip="$prip1/32"
    echo $sgip

    $sgip1="$pubip1/32"
    echo $sgip1

    $updatesg1=aws ec2 authorize-security-group-ingress --group-id "$ManagerNodeSGid1" --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip}]" --profile mfa --output text
    echo $updatesg1

    $updatesg1=aws ec2 authorize-security-group-ingress --group-id "$ManagerNodeSGid1" --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip1}]" --profile mfa --output text
    echo $updatesg1

    $s = New-PSSession -ComputerName $pubip1 -Credential $Cred
    echo $prip

    $output=Invoke-command -Session $s -filepath NetworkJoin.ps1 -argumentlist $Masterpubip,$prip1
    echo $output

} 

if($input -eq 2){

   write-host("Value of X is 2")
   Start-Sleep -s 60
   echo "------------------Configuration Changes- 2-----------------------------------"
   echo "#####################################################################"


   $Nodepubip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
   $Nodeprip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
  
   $sgip1="$Nodepubip1/32"
   #echo $sgip1
   $sgip2="$Nodeprip1/32"
   #echo $sgip2
   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip1}]" --profile mfa --output text
   #echo $updatesg1

   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip2}]" --profile mfa --output text
   #echo $updatesg1
   

   $Nodepubip2=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
   $Nodeprip2=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
   

   $sgip1="$Nodepubip2/32"
   #echo $sgip1
   $sgip2="$Nodeprip2/32"
   #echo $sgip2
   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip1}]" --profile mfa --output text
   #echo $updatesg1

   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip2}]" --profile mfa --output text
   #echo $updatesg1


   $s = New-PSSession -ComputerName $Nodepubip1 -Credential $Cred
   $output=Invoke-command -Session $s -filepath NetworkJoin.ps1 -argumentlist $Masterpubip,$Nodeprip1
   echo $output

   $s = New-PSSession -ComputerName $Nodepubip2 -Credential $Cred
   $output=Invoke-command -Session $s -filepath NetworkJoin.ps1 -argumentlist $Masterpubip,$Nodeprip2
   echo $output

   echo "------------------Configuration Changes completed-----------------------------------"
   echo "#####################################################################"
} 

if($input -eq 3){
   write-host("Value of X is 3")
   echo "------------------Configuration Changes- 3-----------------------------------"
   echo "#####################################################################"
  


   $Nodepubip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
   #echo $Nodepubip1
   $Nodeprip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
   echo $Nodeprip1,$Nodepubip1


   $Nodepubip2=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
   #echo $Nodepubip2
   $Nodeprip2=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
   echo $Nodeprip2,Nodepubip2


   $Nodepubip3=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode-3" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
   #echo $Nodepubip3
   $Nodeprip3=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode-3" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
   echo $Nodeprip3,Nodepubip3


   $sgip1="$Nodeprip1/32"
   #echo $sgip1
   $sgip2="$Nodeprip2/32"
   #echo $sgip2
   $sgip3="$Nodeprip3/32"
   #echo $sgip3

   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip1}]" --profile mfa --output text
   #echo $updatesg1

   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip2}]" --profile mfa --output text
   #echo $updatesg1

   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip3}]" --profile mfa --output text
   #echo $updatesg1

   $sgip1="$Nodepubip1/32"
   #echo $sgip1
   $sgip2="$Nodepubip2/32"
   #echo $sgip2
   $sgip3="$Nodepubip3/32"
   #echo $sgip3

   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip1}]" --profile mfa --output text
   #echo $updatesg1

   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip2}]" --profile mfa --output text
   #echo $updatesg1

   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip3}]" --profile mfa --output text
   #echo $updatesg1

   $s = New-PSSession -ComputerName $Nodepubip1 -Credential $Cred
   echo $prip
   $output=Invoke-command -Session $s -filepath NetworkJoin.ps1 -argumentlist $Masterpubip,$Nodeprip1
   echo $output


   $s = New-PSSession -ComputerName $Nodepubip2 -Credential $Cred
   echo $prip
   $output=Invoke-command -Session $s -filepath NetworkJoin.ps1 -argumentlist $Masterpubip,$Nodeprip2
   echo $output

   $s = New-PSSession -ComputerName $Nodepubip3 -Credential $Cred
   echo $prip
   $output=Invoke-command -Session $s -filepath NetworkJoin.ps1 -argumentlist $Masterpubip,$Nodeprip3
   echo $output
   
   echo "------------------Configuration Changes completed-----------------------------------"
   echo "#####################################################################"
} 








