
aws cloudformation create-stack --stack-name WinSwarmWorker1 --template-body file://WindowsWorker.yaml --parameters file://WindowsWorker.json --profile mfa --output text
aws cloudformation wait stack-create-complete --stack-name WinSwarmWorker1 --profile mfa --output text
Start-Sleep -s 120
$input = $args[0]
echo $input
$Username="Administrator"
$Password='6uff(54P)MYgPDYGax-uzSfxI5E$MP-@'
$pass = ConvertTo-SecureString -AsPlainText $Password -Force
$Cred = New-Object System.Management.Automation.PSCredential -ArgumentList $Username,$pass
if($input -eq 1){
    $pubip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
    echo $pubip1

    $s = New-PSSession -ComputerName $pubip1 -Credential $Cred
    $num=get-random -maximum 10000
    $alpha=-join((65..90) + (97..122) | Get-Random -Count 5 | % {[char]$_})
    $newname="Winodws2019Kubernetes"+"-"+$alpha+"-"+$num
    Invoke-command -Session $s -ScriptBlock { Rename-computer $using:newname -Force }
    Invoke-command -Session $s -ScriptBlock { Restart-Computer -Force }
    
}
if($input -eq 2){
    $id1=aws ec2 describe-tags --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" --query "Tags[0].ResourceId" --profile mfa --output text
    echo $id1
    $id2=aws ec2 describe-tags --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" --query "Tags[1].ResourceId" --profile mfa --output text
    echo $id2
    aws ec2 delete-tags --resources $id2 --tags Key=Name,Value=Kubenetes-Windows-WorkerNode --profile mfa --output text
    aws ec2 create-tags --resources $id2  --tags Key=Name,Value=Kubenetes-Windows-WorkerNode-2 --profile mfa --output text
 
    $Nodepubip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
    echo $Nodepubip1

    $s = New-PSSession -ComputerName $Nodepubip1 -Credential $Cred
    echo $s
    $num=get-random -maximum 10000
    $alpha=-join((65..90) + (97..122) | Get-Random -Count 5 | % {[char]$_})
    $newname="Winodws2019Kubernetes"+"-"+$alpha+"-"+$num
    Invoke-command -Session $s -ScriptBlock { Rename-computer $using:newname -Force }
    #Invoke-command -Session $s -ScriptBlock { Restart-Computer -Force }

    $Nodepubip2=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
    $s = New-PSSession -ComputerName $Nodepubip2 -Credential $Cred
    $num=get-random -maximum 10000
    $alpha=-join((65..90) + (97..122) | Get-Random -Count 5 | % {[char]$_})
    $newname="Winodws2019Kubernetes"+"-"+$alpha+"-"+$num
    Invoke-command -Session $s -ScriptBlock { Rename-computer $using:newname -Force }
    #Invoke-command -Session $s -ScriptBlock { Restart-Computer -Force }
    #aws ec2 reboot-instances --instance-ids $id1
    #aws ec2 reboot-instances --instance-ids $id2
}

if($input -eq 3){
    $id1=aws ec2 describe-tags --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" --query "Tags[0].ResourceId" --profile mfa --output text
    echo $id1
    $id2=aws ec2 describe-tags --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" --query "Tags[1].ResourceId" --profile mfa --output text
    #echo $id2
 
 
    $id3=aws ec2 describe-tags --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" --query "Tags[2].ResourceId" --profile mfa --output text
    echo $id2,$id3
 
    aws ec2 delete-tags --resources $id2 --tags Key=Name,Value=Kubenetes-Windows-WorkerNode --profile mfa --output text
    aws ec2 delete-tags --resources $id3 --tags Key=Name,Value=Kubenetes-Windows-WorkerNode --profile mfa --output text
 
    aws ec2 create-tags --resources $id2  --tags Key=Name,Value=Kubenetes-Windows-WorkerNode-2 --profile mfa --output text
    aws ec2 create-tags --resources $id3  --tags Key=Name,Value=Kubenetes-Windows-WorkerNode-3 --profile mfa --output text

    $Nodepubip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
    $s = New-PSSession -ComputerName $Nodepubip1 -Credential $Cred
    $num=get-random -maximum 10000
    $alpha=-join((65..90) + (97..122) | Get-Random -Count 5 | % {[char]$_})
    $newname="Winodws2019Kubernetes"+"-"+$alpha+"-"+$num
    Invoke-command -Session $s -ScriptBlock { Rename-computer $using:newname -Force }
    #Invoke-command -Session $s -ScriptBlock { Restart-Computer -Force }

    $Nodepubip2=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
    $s = New-PSSession -ComputerName $Nodepubip2 -Credential $Cred
    $num=get-random -maximum 10000
    $alpha=-join((65..90) + (97..122) | Get-Random -Count 5 | % {[char]$_})
    $newname="Winodws2019Kubernetes"+"-"+$alpha+"-"+$num
    Invoke-command -Session $s -ScriptBlock { Rename-computer $using:newname -Force }
    #Invoke-command -Session $s -ScriptBlock { Restart-Computer -Force }

    $Nodepubip3=aws ec2 describe-instances --filters "Name=tag:Name,Values=Kubenetes-Windows-WorkerNode-3" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
    $s = New-PSSession -ComputerName $Nodepubip3 -Credential $Cred
    $num=get-random -maximum 10000
    $alpha=-join((65..90) + (97..122) | Get-Random -Count 5 | % {[char]$_})
    $newname="Winodws2019Kubernetes"+"-"+$alpha+"-"+$num
    Invoke-command -Session $s -ScriptBlock { Rename-computer $using:newname -Force }
    #Invoke-command -Session $s -ScriptBlock { Restart-Computer -Force }
    aws ec2 reboot-instances --instance-ids $id1
    aws ec2 reboot-instances --instance-ids $id1
    aws ec2 reboot-instances --instance-ids $id3

}

