
aws cloudformation create-stack --stack-name WinSwarmManager1 --template-body file://WindowsManager.yaml --parameters file://WindowsManager.json --profile mfa --output text
aws cloudformation wait stack-create-complete --stack-name WinSwarmManager1 --profile mfa --output text
aws cloudformation create-stack --stack-name WinSwarmWorker1 --template-body file://WindowsWorker.yaml --parameters file://WindowsWorker.json --profile mfa --output text
aws cloudformation wait stack-create-complete --stack-name WinSwarmWorker1 --profile mfa --output text

$Username="Administrator"
$Password="LaMU3NUCEObpYHNEDinYS!Vjs)L)gl&r"
$pass = ConvertTo-SecureString -AsPlainText $Password -Force
$Cred = New-Object System.Management.Automation.PSCredential -ArgumentList $Username,$pass


$pubip=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-ManagerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
echo $pubip

$prip=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-ManagerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
echo $prip

$ubuntuprip=aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-ManagerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
#echo $prip

$ManagerNodeSGid1=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-ManagerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].SecurityGroups[*].GroupId" --profile mfa --output text
#echo $ManagerNodeSGid1



$s = New-PSSession -ComputerName $pubip -Credential $Cred

$managertoken=get-content -Path C:\Users\Administrator\Desktop\HybridCluster\Ubuntu\managertoken.txt 
echo $managertoken

Invoke-command -Session $s -ScriptBlock {docker swarm join --token $using:managertoken $using:ubuntuprip':2377'}


$workerToken=get-content -Path C:\Users\Administrator\Desktop\HybridCluster\Ubuntu\workertoken.txt 
echo $workerToken

Start-Sleep -s 120

$input = $args[0]
echo $input
if($input -eq 1)
{
    write-host("Value of X is 1")
    Start-Sleep -s 60

    $pubip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
    echo $pubip1
    $prip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
    echo $prip1

    $sgip="$prip1/32"
    echo $sgip

    $sgip1="$pubip1/32"
    echo $sgip1

    echo $ManagerNodeSGid1
    $updatesg1=aws ec2 authorize-security-group-ingress --group-id "$ManagerNodeSGid1" --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip}]" --profile mfa --output text
    echo $updatesg1

    $updatesg1=aws ec2 authorize-security-group-ingress --group-id "$ManagerNodeSGid1" --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip1}]" --profile mfa --output text
    echo $updatesg1

    $s = New-PSSession -ComputerName $pubip1 -Credential $Cred
    echo $prip
    
    $output=Invoke-command -Session $s -ScriptBlock {docker swarm join --token $using:workerToken $using:ubuntuprip':2377'}
    echo $output

} 

if($input -eq 2){

   write-host("Value of X is 2")
   Start-Sleep -s 60
   echo "------------------Configuration Changes- 2-----------------------------------"
   echo "#####################################################################"

   $id2=aws ec2 describe-tags --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode" --query "Tags[1].ResourceId" --profile mfa --output text
   echo $id2
   aws ec2 delete-tags --resources $id2 --tags Key=Name,Value=WindowsSwarm-WorkerNode --profile mfa --output text
   aws ec2 create-tags --resources $id2  --tags Key=Name,Value=WindowsSwarm-WorkerNode-2 --profile mfa --output text

   $Nodepubip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
   $Nodeprip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
   echo $Nodepubip1,$Nodeprip1

   $s = New-PSSession -ComputerName $Nodepubip1 -Credential $Cred
   echo $Nodepubip1
   $output=Invoke-command -Session $s -ScriptBlock {docker swarm join --token $using:workerToken $using:ubuntuprip':2377'}
   echo $output

   $Nodepubip2=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
   $Nodeprip2=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
   
   $s = New-PSSession -ComputerName $Nodepubip2 -Credential $Cred
   echo $Nodepubip2
   $output=Invoke-command -Session $s -ScriptBlock {docker swarm join --token $using:workerToken $using:ubuntuprip':2377'}
   echo $output

   $sgip1="$Nodeprip1/32"
   #echo $sgip1
   $sgip2="$Nodeprip2/32"
   #echo $sgip2
   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip1}]" --profile mfa --output text
   #echo $updatesg1

   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip2}]" --profile mfa --output text
   #echo $updatesg1
   echo "------------------Configuration Changes completed-----------------------------------"
   echo "#####################################################################"
} 

if($input -eq 3){
   write-host("Value of X is 3")
   echo "------------------Configuration Changes- 3-----------------------------------"
   echo "#####################################################################"
  
   $id2=aws ec2 describe-tags --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode" --query "Tags[1].ResourceId" --profile mfa --output text
   #echo $id2


   $id3=aws ec2 describe-tags --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode" --query "Tags[2].ResourceId" --profile mfa --output text
   echo $id2,$id3

   aws ec2 delete-tags --resources $id2 --tags Key=Name,Value=WindowsSwarm-WorkerNode --profile mfa --output text
   aws ec2 delete-tags --resources $id3 --tags Key=Name,Value=WindowsSwarm-WorkerNode --profile mfa --output text

   aws ec2 create-tags --resources $id2  --tags Key=Name,Value=WindowsSwarm-WorkerNode-2 --profile mfa --output text
   aws ec2 create-tags --resources $id3  --tags Key=Name,Value=WindowsSwarm-WorkerNode-3 --profile mfa --output text

   $Nodepubip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
   #echo $Nodepubip1
   $Nodeprip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
   echo $Nodeprip1,$Nodepubip1


   $Nodepubip2=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
   #echo $Nodepubip2
   $Nodeprip2=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
   echo $Nodeprip2,Nodepubip2


   $Nodepubip3=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode-3" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --profile mfa --output text
   #echo $Nodepubip3
   $Nodeprip3=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode-3" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --profile mfa --output text
   echo $Nodeprip3,Nodepubip3


   $s = New-PSSession -ComputerName $Nodepubip1 -Credential $Cred
   echo $prip
   $output=Invoke-command -Session $s -ScriptBlock {docker swarm join --token $using:workerToken $using:ubuntuprip':2377'}
   echo $output

   $s = New-PSSession -ComputerName $Nodepubip2 -Credential $Cred
   echo $prip
   $output=Invoke-command -Session $s -ScriptBlock {docker swarm join --token $using:workerToken $using:ubuntuprip':2377'}
   echo $output

   $s = New-PSSession -ComputerName $Nodepubip3 -Credential $Cred
   echo $prip
   $output=Invoke-command -Session $s -ScriptBlock {docker swarm join --token $using:workerToken $using:ubuntuprip':2377'}
   echo $output

   $sgip1="$Nodeprip1/32"
   #echo $sgip1
   $sgip2="$Nodeprip2/32"
   #echo $sgip2
   $sgip3="$Nodepubip3/32"
   #echo $sgip3

   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip1}]" --profile mfa --output text
   #echo $updatesg1

   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip2}]" --profile mfa --output text
   #echo $updatesg1

   $updatesg1=aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol="-1",IpRanges="[{CidrIp=$sgip3}]" --profile mfa --output text
   #echo $updatesg1
   echo "------------------Configuration Changes completed-----------------------------------"
   echo "#####################################################################"
} 








