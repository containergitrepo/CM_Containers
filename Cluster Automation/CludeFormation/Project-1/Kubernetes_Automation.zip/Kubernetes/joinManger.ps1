$Username="Administrator"
$Password="LaMU3NUCEObpYHNEDinYS!Vjs)L)gl&r"
$pass = ConvertTo-SecureString -AsPlainText $Password -Force
$Cred = New-Object System.Management.Automation.PSCredential -ArgumentList $Username,$pass

$prip=aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-ManagerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" 
echo $prip

$val=get-content -Path C:\Users\Administrator\Desktop\HybridCluster\workerToken.txt 
echo $val

$input = $args[0]
echo $input
if($input -eq 1)
{
    $pubip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text
    echo $pubip1
    $s = New-PSSession -ComputerName $pubip1 -Credential $Cred
    echo $prip
    $output=Invoke-command -Session $s -ScriptBlock {docker swarm join --token $using:val $using:prip':2377'}
    echo $output
}

if($input -eq 2)
{
    $pubip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text
    echo $pubip1
    $s = New-PSSession -ComputerName $pubip1 -Credential $Cred
    echo $prip
    $output=Invoke-command -Session $s -ScriptBlock {docker swarm join --token $using:val $using:prip':2377'}
    echo $output

    $Nodepubip2=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text
    $s = New-PSSession -ComputerName $Nodepubip2 -Credential $Cred
    echo $prip
    $output=Invoke-command -Session $s -ScriptBlock {docker swarm join --token $using:val $using:prip':2377'}
    echo $output
}

if($input -eq 3)
{
    $pubip1=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text
    echo $pubip1
    $s = New-PSSession -ComputerName $pubip1 -Credential $Cred
    echo $prip
    $output=Invoke-command -Session $s -ScriptBlock {docker swarm join --token $using:val $using:prip':2377'}
    echo $output

    $Nodepubip2=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text
    $s = New-PSSession -ComputerName $Nodepubip2 -Credential $Cred
    echo $prip
    $output=Invoke-command -Session $s -ScriptBlock {docker swarm join --token $using:val $using:prip':2377'}
    echo $output

    $Nodepubip3=aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-WorkerNode-3" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text
   #echo $Nodepubip3
    $s = New-PSSession -ComputerName $Nodepubip3 -Credential $Cred
    echo $prip
    $output=Invoke-command -Session $s -ScriptBlock {docker swarm join --token $using:val $using:prip':2377'}
    echo $output
}