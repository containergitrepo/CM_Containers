#!/bin/bash -e

echo "#####################################################################"
echo "------------------Executing CloudFormation demo--------------------------------"
echo "#####################################################################"
aws cloudformation create-stack --stack-name NetworkELB1 --template-body file://NetworkELB.yaml --parameters file://ELBParams.json
aws cloudformation wait stack-create-complete --stack-name NetworkELB1
echo "------------------Provisioning ManagerNode-----------------------------------"
echo "#####################################################################"
aws cloudformation create-stack --stack-name ubuntuKubernetesManager1 --template-body file://DockerSwarmManger.yaml --parameters file://DockerSwarmManagerParam.json
aws cloudformation wait stack-create-complete --stack-name ubuntuKubernetesManager1
echo "------------------Provisioning WorkerNode-----------------------------------"
echo "#####################################################################"
aws cloudformation create-stack --stack-name ubuntuKubernetesWorker --template-body file://DockerSwarmWorker.yaml --parameters file://DockerSwarmWokerParam.json
aws cloudformation wait stack-create-complete --stack-name ubuntuKubernetesWorker

sleep 2m

pubip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-ManagerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $pubip

prip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-ManagerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
#echo $prip

workertoken=$(ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem ubuntu@$pubip '( docker swarm join-token worker --quiet )')
#echo $token
echo $workertoken>workertoken.txt

managertoken=$(ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem ubuntu@$pubip '( docker swarm join-token manager --quiet )')
#echo $managertoken
echo $managertoken>managertoken.txt

ManagerNodeSGid1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-ManagerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].SecurityGroups[*].GroupId" --output text)
#echo $ManagerNodeSGid1



if [ $1 == "1" ]
then
#echo Hey its 1.
echo "------------------Configuration Changes- 1-----------------------------------"
echo "#####################################################################"
sleep 2m

pubip1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
#echo $pubip1
prip1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
#echo $prip1

sgip="$prip1/32"
#echo $sgip

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

output=$(ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem ubuntu@$pubip1 '( docker swarm join --token '$workertoken' '$prip':2377 )')
#echo $output
echo "------------------Configuration Changes completed -----------------------------------"
echo "#####################################################################"
fi


if [ $1 == "2" ]
then
#echo Hey its 2.
echo "------------------Configuration Changes- 2-----------------------------------"
echo "#####################################################################"
sleep 2m

id2=$(aws ec2 describe-tags --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode" --query "Tags[1].ResourceId" --output text)
#echo $id2
aws ec2 delete-tags --resources $id2 --tags Key=Name,Value=DockerSwarm-WorkerNode
aws ec2 create-tags --resources $id2  --tags Key=Name,Value=DockerSwarm-WorkerNode-2

Nodepubip1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
Nodeprip1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
#echo $Nodeprip1


Nodepubip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
Nodeprip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)

output=$(ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem ubuntu@$Nodepubip1 '( docker swarm join --token '$workertoken' '$prip':2377 )')
#echo $output
output=$(ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem ubuntu@$Nodepubip2 '( docker swarm join --token '$workertoken' '$prip':2377 )')
#echo $output

sgip1="$Nodeprip1/32"
#echo $sgip1
sgip2="$Nodeprip2/32"
#echo $sgip2
updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip1"}])
#echo $updatesg1

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip2"}])
#echo $updatesg1
echo "------------------Configuration Changes completed-----------------------------------"
echo "#####################################################################"
fi



if [ $1 == "3" ]
then
#echo Hey its 3.
echo "------------------Configuration Changes- 3-----------------------------------"
echo "#####################################################################"
sleep 2m
id2=$(aws ec2 describe-tags --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode" --query "Tags[1].ResourceId" --output text)
#echo $id2


id3=$(aws ec2 describe-tags --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode" --query "Tags[2].ResourceId" --output text)
#echo $id3

aws ec2 delete-tags --resources $id2 --tags Key=Name,Value=DockerSwarm-WorkerNode
aws ec2 delete-tags --resources $id3 --tags Key=Name,Value=DockerSwarm-WorkerNode

aws ec2 create-tags --resources $id2  --tags Key=Name,Value=DockerSwarm-WorkerNode-2
aws ec2 create-tags --resources $id3  --tags Key=Name,Value=DockerSwarm-WorkerNode-3

Nodepubip1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
#echo $Nodepubip1
Nodeprip1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
#echo $Nodeprip1


Nodepubip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
#echo $Nodepubip2
Nodeprip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
#echo $Nodeprip2


Nodepubip3=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode-3" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
#echo $Nodepubip3
Nodeprip3=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode-3" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
#echo $Nodeprip3


output=$(ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem ubuntu@$Nodepubip1 '( docker swarm join --token '$workertoken' '$prip':2377 )')
#echo $output
output=$(ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem ubuntu@$Nodepubip2 '( docker swarm join --token '$workertoken' '$prip':2377 )')
#echo $output
output=$(ssh -o "StrictHostKeyChecking no" -i DockerAutomation.pem ubuntu@$Nodepubip3 '( docker swarm join --token '$workertoken' '$prip':2377 )')
#echo $output

sgip1="$Nodeprip1/32"
#echo $sgip1
sgip2="$Nodeprip2/32"
#echo $sgip2
sgip3="$Nodepubip3/32"
#echo $sgip3

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip1"}])
#echo $updatesg1

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip2"}])
#echo $updatesg1

updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $ManagerNodeSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip3"}])
#echo $updatesg1
echo "------------------Configuration Changes completed-----------------------------------"
echo "#####################################################################"
fi

workerSGid1=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].SecurityGroups[*].GroupId" --output text)
#echo $workerSGid1

sgip="$prip/32"
#echo $sgip
updatesg1=$(aws ec2 authorize-security-group-ingress --group-id $workerSGid1 --ip-permissions IpProtocol=-1,IpRanges=[{"CidrIp"="$sgip"}])
#echo $updatesg1

echo "------------------Configuration Changes to master completed-----------------------------------"
echo "#####################################################################"

echo "------------------Application deployment started-----------------------------------"
echo "#####################################################################"
app=$(ssh -i DockerAutomation.pem ubuntu@$pubip '( sudo docker stack deploy --compose-file appstack.yml wordpress-app)')
#echo $app


sleep 4m

echo "------------------Application deployment completed-----------------------------------"
echo "#####################################################################"








