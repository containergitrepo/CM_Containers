prip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=WindowsSwarm-ManagerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PrivateIpAddress" --output text)
echo $prip

val=$(iconv -c -f utf-8 -t ascii 'C:/Users/Administrator/Desktop/HybridCluster/workerToken.txt')
echo $val

if [ $1 == "1" ]
then

pubip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $pubip


output=$(ssh -o "StrictHostKeyChecking no" -i DockerHybrid.pem ubuntu@$pubip '( docker swarm join --token '$val' '$prip':2377 )')
echo $output

fi

if [ $1 == "2" ]
then

pubip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $pubip

pubip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $pubip2

output=$(ssh -o "StrictHostKeyChecking no" -i DockerHybrid.pem ubuntu@$pubip '( docker swarm join --token '$val' '$prip':2377 )')
echo $output

output=$(ssh -o "StrictHostKeyChecking no" -i DockerHybrid.pem ubuntu@$pubip2 '( docker swarm join --token '$val' '$prip':2377 )')
echo $output

fi


if [ $1 == "3" ]
then

pubip=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $pubip

pubip2=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode-2" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $pubip2

pubip3=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=DockerSwarm-WorkerNode-3" "Name=instance-state-name,Values=running" --query "Reservations[*].Instances[*].PublicIpAddress" --output text)
echo $pubip3

output=$(ssh -o "StrictHostKeyChecking no" -i DockerHybrid.pem ubuntu@$pubip '( docker swarm join --token '$val' '$prip':2377 )')
echo $output

output=$(ssh -o "StrictHostKeyChecking no" -i DockerHybrid.pem ubuntu@$pubip2 '( docker swarm join --token '$val' '$prip':2377 )')
echo $output

output=$(ssh -o "StrictHostKeyChecking no" -i DockerHybrid.pem ubuntu@$pubip3 '( docker swarm join --token '$val' '$prip':2377 )')
echo $output


fi
